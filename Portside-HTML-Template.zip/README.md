# Portside — Client Operations Hub Template

A front-end template for developers building agency and freelancer tools: a marketing
site paired with a working client-portal application UI (clients, projects, tasks,
proposals, invoices, files). Semantic HTML5, modern CSS with a token-based design system,
and vanilla JavaScript — no build step, no framework, no backend included.

## Key features

- 17 pages: 6 marketing/auth pages, 10 application screens, 1 documentation page
- Reusable design system: buttons, cards, badges, tables, forms, tabs, accordions, modals,
  dropdown menus, toasts, alerts, pagination, empty states, skeleton loaders
- Real, working interactions: sortable/filterable tables, a drag-and-drop task board
  (with a keyboard-accessible fallback), modal dialogs, dropdown menus, toast
  notifications, client-side form validation, password visibility toggles, copy-to-
  clipboard
- Realistic fictional demo data (a fictional agency, "Northline Studio," with 8 fictional
  clients) — no Lorem Ipsum, no fake testimonials, no fake ratings or statistics
- Responsive from 320px to 1920px, with a deliberate mobile layout for the app sidebar,
  data tables, and task board
- Accessibility-conscious: semantic landmarks, visible focus states, keyboard-operable
  modals/tabs/accordions/task board, labelled form fields, skip-to-content link

## Technology

Semantic HTML5, CSS custom properties (design tokens), vanilla JavaScript (ES2017+, one
shared file, no dependencies). No React/Vue/Angular, no bundler, no npm install required
to use the template.

## Browser support

Current versions of Chrome, Firefox, Safari, and Edge. Uses the native `<dialog>` element
and the Popover API — see `documentation/index.html#browser-support` for exact version
support and one documented iOS Safari limitation.

## Installation

Open `index.html` directly, or serve the folder locally:

```
python3 -m http.server 8000
```

Full instructions: `documentation/index.html`.

## Customization

See `documentation/index.html#quickstart` — "Customize in 10 Minutes" — for renaming the
product, recoloring via design tokens, replacing demo data, and connecting forms to a
real backend.

## File structure

```
portside/
  index.html, features.html, pricing.html, login.html, register.html, 404.html
  dashboard.html, clients.html, client-details.html, projects.html,
  project-details.html, tasks.html, proposals.html, invoices.html,
  files.html, settings.html
  assets/css/styles.css
  assets/js/app.js
  assets/images/
  documentation/index.html
```

## Documentation

Full reference: `documentation/index.html` (design tokens, component list, page-by-page
notes, JS functionality, deployment, and known limitations of the static demo).

## Credits

All icons and illustrations are original, built specifically for this template (see
`THIRD-PARTY-LICENSES.txt`). No third-party icon packs, stock photography, or web fonts
are used.

## Licensing

See `LICENSE.txt`. Regular License: for a single end product not charged to its users.
Extended License: for a single end product that end users pay to access. See the pricing
page in the template itself for the full comparison.

## Support

This is a template, not a hosted service — there is no account system to contact for
support. Refer to `documentation/index.html` first; most customization questions are
answered there or in the inline comments within `assets/css/styles.css` and
`assets/js/app.js`.

## Changelog

See `CHANGELOG.md`.
