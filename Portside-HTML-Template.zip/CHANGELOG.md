# Changelog

All notable changes to Portside are documented here.

## [1.0.0] — 2026-09-07

Initial release.

### Added
- 6 marketing/auth pages: Home, Features, Pricing, Login, Register, 404
- 10 application screens: Dashboard, Clients, Client Details, Projects, Project Details,
  Tasks, Proposals, Invoices, Files, Settings
- Full documentation page
- Shared design system (`assets/css/styles.css`) covering buttons, cards, badges, forms,
  tables, tabs, accordions, modals, dropdown menus, toasts, alerts, pagination, empty
  states, and the drag-and-drop task board
- Shared interaction layer (`assets/js/app.js`): mobile navigation, sidebar collapse,
  tabs, accordions, modal dialogs, popover positioning, toast notifications, dismissible
  alerts, password visibility toggles, client-side form validation, sortable tables,
  live filtering, copy-to-clipboard, drag-and-drop task board with a keyboard-accessible
  fallback, and demo status-change actions for proposals/invoices
- Original SVG icon sprite and homepage illustration
- Realistic fictional demo data throughout (Northline Studio and 8 fictional clients)

### Known limitations (by design — see documentation for details)
- No backend, database, authentication, or payment processing
- Forms are front-end validation only; submissions do not persist
- Dark mode is not included in this release (see documentation for planned variants)
