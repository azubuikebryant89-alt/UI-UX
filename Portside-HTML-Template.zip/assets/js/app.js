/**
 * Portside — shared interaction layer.
 * Vanilla JS, no dependencies. Every function checks the DOM before wiring up,
 * so this single file can be safely included on every page (marketing + app).
 */
(function () {
  "use strict";

  /* ---------------------------------------------------------
     0. Utilities
  --------------------------------------------------------- */
  const $ = (sel, ctx) => (ctx || document).querySelector(sel);
  const $$ = (sel, ctx) => Array.from((ctx || document).querySelectorAll(sel));

  /* ---------------------------------------------------------
     1. Marketing site: mobile nav toggle
  --------------------------------------------------------- */
  function initMobileNav() {
    const toggle = $(".nav-toggle");
    const nav = $(".mobile-nav");
    if (!toggle || !nav) return;
    toggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", String(isOpen));
      document.body.style.overflow = isOpen ? "hidden" : "";
    });
    $$("a", nav).forEach((link) =>
      link.addEventListener("click", () => {
        nav.classList.remove("is-open");
        toggle.setAttribute("aria-expanded", "false");
        document.body.style.overflow = "";
      })
    );
  }

  /* ---------------------------------------------------------
     2. App shell: sidebar collapse (desktop) + mobile drawer
  --------------------------------------------------------- */
  function initAppShell() {
    const shell = $(".app-shell");
    if (!shell) return;

    const collapseBtn = $(".sidebar-collapse-btn");
    if (collapseBtn) {
      const stored = localStorage.getItem("portside:sidebar-collapsed");
      if (stored === "true") shell.classList.add("is-collapsed");
      collapseBtn.addEventListener("click", () => {
        const collapsed = shell.classList.toggle("is-collapsed");
        localStorage.setItem("portside:sidebar-collapsed", String(collapsed));
        collapseBtn.setAttribute("aria-label", collapsed ? "Expand sidebar" : "Collapse sidebar");
      });
    }

    const mobileBtn = $(".mobile-menu-btn");
    const scrim = $(".sidebar-scrim");
    function closeMobileSidebar() {
      shell.classList.remove("sidebar-mobile-open");
      if (mobileBtn) mobileBtn.setAttribute("aria-expanded", "false");
    }
    if (mobileBtn) {
      mobileBtn.addEventListener("click", () => {
        const open = shell.classList.toggle("sidebar-mobile-open");
        mobileBtn.setAttribute("aria-expanded", String(open));
      });
    }
    if (scrim) scrim.addEventListener("click", closeMobileSidebar);
    $$(".sidebar-nav a").forEach((a) => a.addEventListener("click", closeMobileSidebar));
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closeMobileSidebar();
    });
  }

  /* ---------------------------------------------------------
     3. Tabs (WAI-ARIA tabs pattern)
  --------------------------------------------------------- */
  function initTabs() {
    $$("[data-tabs]").forEach((group) => {
      const tabs = $$(".tab-btn", group);
      const panels = tabs.map((t) => document.getElementById(t.getAttribute("aria-controls")));

      function activate(index) {
        tabs.forEach((t, i) => {
          const active = i === index;
          t.setAttribute("aria-selected", String(active));
          t.tabIndex = active ? 0 : -1;
          if (panels[i]) panels[i].hidden = !active;
        });
        tabs[index].focus();
      }

      tabs.forEach((tab, i) => {
        tab.addEventListener("click", () => activate(i));
        tab.addEventListener("keydown", (e) => {
          if (e.key === "ArrowRight") activate((i + 1) % tabs.length);
          if (e.key === "ArrowLeft") activate((i - 1 + tabs.length) % tabs.length);
        });
      });
    });
  }

  /* ---------------------------------------------------------
     4. Accordion (FAQ, changelog-style groups)
  --------------------------------------------------------- */
  function initAccordions() {
    $$(".accordion-trigger").forEach((trigger) => {
      trigger.addEventListener("click", () => {
        const expanded = trigger.getAttribute("aria-expanded") === "true";
        const panel = document.getElementById(trigger.getAttribute("aria-controls"));
        trigger.setAttribute("aria-expanded", String(!expanded));
        if (panel) panel.hidden = expanded;
      });
    });
  }

  /* ---------------------------------------------------------
     5. Modal dialogs (native <dialog>)
  --------------------------------------------------------- */
  function initModals() {
    $$("[data-modal-open]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const dialog = document.getElementById(btn.getAttribute("data-modal-open"));
        if (dialog && typeof dialog.showModal === "function") {
          dialog._lastTrigger = btn; // remembered so focus returns here on close
          dialog.showModal();
        }
      });
    });
    $$("dialog.modal").forEach((dialog) => {
      $$("[data-modal-close]", dialog).forEach((btn) =>
        btn.addEventListener("click", () => dialog.close())
      );
      // Click on backdrop closes the dialog
      dialog.addEventListener("click", (e) => {
        const rect = dialog.getBoundingClientRect();
        const inside =
          e.clientX >= rect.left && e.clientX <= rect.right && e.clientY >= rect.top && e.clientY <= rect.bottom;
        if (!inside) dialog.close();
      });
      // Explicit focus restoration: don't rely on inconsistent browser defaults.
      dialog.addEventListener("close", () => {
        if (dialog._lastTrigger && typeof dialog._lastTrigger.focus === "function") {
          dialog._lastTrigger.focus();
        }
      });
    });
  }

  /* ---------------------------------------------------------
     5b. Popover positioning (dropdown menus anchored to their trigger)
     CSS Anchor Positioning isn't reliably supported across browsers yet,
     so position is computed from the trigger's rect on the "beforetoggle"
     event instead — works everywhere the Popover API itself works.
  --------------------------------------------------------- */
  function initPopoverPositioning() {
    $$("[popover]").forEach((popover) => {
      const anchorId = popover.getAttribute("data-anchor");
      const trigger = anchorId ? document.getElementById(anchorId) : null;
      if (!trigger) return;

      popover.addEventListener("beforetoggle", (e) => {
        if (e.newState !== "open") return;
        const rect = trigger.getBoundingClientRect();
        const menuWidth = popover.offsetWidth || 240;
        let left = rect.right - menuWidth;
        left = Math.max(8, Math.min(left, window.innerWidth - menuWidth - 8));
        let top = rect.bottom + 8;
        popover.style.left = left + "px";
        popover.style.top = top + "px";

        // If it would overflow the bottom of the viewport, open upward instead.
        requestAnimationFrame(() => {
          const menuHeight = popover.offsetHeight;
          if (top + menuHeight > window.innerHeight - 8) {
            popover.style.top = Math.max(8, rect.top - menuHeight - 8) + "px";
          }
        });
      });
    });
  }

  /* ---------------------------------------------------------
     6. Toast notifications
  --------------------------------------------------------- */
  function ensureToastRegion() {
    let region = $(".toast-region");
    if (!region) {
      region = document.createElement("div");
      region.className = "toast-region";
      region.setAttribute("aria-live", "polite");
      region.setAttribute("role", "status");
      document.body.appendChild(region);
    }
    return region;
  }

  function showToast(message, type) {
    const region = ensureToastRegion();
    const toast = document.createElement("div");
    toast.className = "toast " + (type || "success");
    toast.innerHTML =
      '<span>' + message + '</span><button class="toast-close" aria-label="Dismiss notification">&times;</button>';
    region.appendChild(toast);
    const remove = () => toast.remove();
    $(".toast-close", toast).addEventListener("click", remove);
    setTimeout(remove, 5000);
  }
  window.PortsideToast = showToast;

  function initToastTriggers() {
    $$("[data-toast]").forEach((el) => {
      el.addEventListener("click", (e) => {
        if (el.tagName === "A" && el.getAttribute("href") === "#") e.preventDefault();
        showToast(el.getAttribute("data-toast"), el.getAttribute("data-toast-type") || "success");
      });
    });
  }

  /* ---------------------------------------------------------
     7. Dismissible alerts
  --------------------------------------------------------- */
  function initAlerts() {
    $$(".alert-close").forEach((btn) =>
      btn.addEventListener("click", () => btn.closest(".alert").remove())
    );
  }

  /* ---------------------------------------------------------
     8. Password visibility toggle
  --------------------------------------------------------- */
  function initPasswordToggles() {
    $$("[data-password-toggle]").forEach((btn) => {
      const input = document.getElementById(btn.getAttribute("data-password-toggle"));
      if (!input) return;
      btn.addEventListener("click", () => {
        const isPassword = input.type === "password";
        input.type = isPassword ? "text" : "password";
        btn.setAttribute("aria-label", isPassword ? "Hide password" : "Show password");
        btn.textContent = isPassword ? "Hide" : "Show";
      });
    });
  }

  /* ---------------------------------------------------------
     9. Form validation (demo-only, front-end)
  --------------------------------------------------------- */
  function initFormValidation() {
    $$("form[data-validate]").forEach((form) => {
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        let valid = true;
        $$("[required]", form).forEach((input) => {
          const field = input.closest(".field") || input.parentElement;
          const invalid = !input.value.trim() || (input.type === "email" && !/^\S+@\S+\.\S+$/.test(input.value));
          if (field) field.classList.toggle("has-error", invalid);
          if (invalid) valid = false;
        });
        if (valid) {
          showToast(form.getAttribute("data-success-message") || "Saved successfully.", "success");
          const demoNote = form.getAttribute("data-demo-note");
          if (demoNote) showToast(demoNote, "info");
        } else {
          showToast("Please check the highlighted fields.", "error");
        }
      });
    });
  }

  /* ---------------------------------------------------------
     10. Table sorting (client-side, per table)
  --------------------------------------------------------- */
  function initTableSort() {
    $$(".data-table").forEach((table) => {
      const headers = $$("th[aria-sort]", table);
      headers.forEach((th, colIndex) => {
        th.addEventListener("click", () => {
          const currentDir = th.getAttribute("aria-sort");
          const nextDir = currentDir === "ascending" ? "descending" : "ascending";
          headers.forEach((h) => h.setAttribute("aria-sort", "none"));
          th.setAttribute("aria-sort", nextDir);

          const tbody = $("tbody", table);
          const rows = $$("tr", tbody);
          const collator = new Intl.Collator(undefined, { numeric: true, sensitivity: "base" });

          rows.sort((a, b) => {
            const aText = a.children[colIndex]?.getAttribute("data-sort-value") || a.children[colIndex]?.textContent.trim() || "";
            const bText = b.children[colIndex]?.getAttribute("data-sort-value") || b.children[colIndex]?.textContent.trim() || "";
            return nextDir === "ascending" ? collator.compare(aText, bText) : collator.compare(bText, aText);
          });
          rows.forEach((row) => tbody.appendChild(row));
        });
      });
    });
  }

  /* ---------------------------------------------------------
     11. Live search / filter (per data-filter-list block)
  --------------------------------------------------------- */
  function initFilters() {
    $$("[data-filter-input]").forEach((input) => {
      const listSelector = input.getAttribute("data-filter-input");
      const items = $$(listSelector);
      function apply() {
        const term = input.value.trim().toLowerCase();
        let visible = 0;
        items.forEach((item) => {
          const text = (item.getAttribute("data-filter-text") || item.textContent).toLowerCase();
          const show = !term || text.includes(term);
          item.hidden = !show;
          if (show) visible++;
        });
        const emptyState = document.querySelector(input.getAttribute("data-filter-empty") || "");
        if (emptyState) emptyState.hidden = visible !== 0;
      }
      input.addEventListener("input", apply);
    });

    // Chip-style status filters
    $$("[data-chip-filter]").forEach((chipGroup) => {
      const chips = $$(".chip", chipGroup);
      const listSelector = chipGroup.getAttribute("data-chip-filter");
      const items = $$(listSelector);
      chips.forEach((chip) => {
        chip.addEventListener("click", () => {
          chips.forEach((c) => c.setAttribute("aria-pressed", "false"));
          chip.setAttribute("aria-pressed", "true");
          const status = chip.getAttribute("data-status");
          items.forEach((item) => {
            item.hidden = status !== "all" && item.getAttribute("data-status") !== status;
          });
        });
      });
    });
  }

  /* ---------------------------------------------------------
     12. Copy to clipboard
  --------------------------------------------------------- */
  function initCopyButtons() {
    $$("[data-copy]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const value = btn.getAttribute("data-copy");
        try {
          await navigator.clipboard.writeText(value);
          showToast("Link copied to clipboard.", "success");
        } catch (err) {
          showToast("Could not copy automatically — please copy manually.", "error");
        }
      });
    });
  }

  /* ---------------------------------------------------------
     13. Task board drag-and-drop (HTML5 DnD, mouse + basic touch fallback via buttons)
  --------------------------------------------------------- */
  function initBoard() {
    const board = $(".board");
    if (!board) return;
    let dragged = null;

    $$(".task-card", board).forEach((card) => {
      card.addEventListener("dragstart", () => {
        dragged = card;
        card.classList.add("is-dragging");
      });
      card.addEventListener("dragend", () => {
        card.classList.remove("is-dragging");
        dragged = null;
      });
    });

    $$(".board-col", board).forEach((col) => {
      const list = $(".board-list", col);
      col.addEventListener("dragover", (e) => {
        e.preventDefault();
        col.classList.add("is-dragover");
      });
      col.addEventListener("dragleave", () => col.classList.remove("is-dragover"));
      col.addEventListener("drop", (e) => {
        e.preventDefault();
        col.classList.remove("is-dragover");
        if (dragged && list) {
          list.appendChild(dragged);
          updateColumnCounts();
          showToast("Task moved to " + col.getAttribute("data-column-name") + ".", "success");
        }
      });
    });

    // Keyboard-accessible fallback: "Move to..." menu button per card
    $$("[data-move-task]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const card = btn.closest(".task-card");
        const targetId = btn.getAttribute("data-move-task");
        const targetList = document.getElementById(targetId);
        if (card && targetList) {
          targetList.appendChild(card);
          updateColumnCounts();
          showToast("Task moved.", "success");
        }
      });
    });

    function updateColumnCounts() {
      $$(".board-col", board).forEach((col) => {
        const count = $$(".task-card", col).length;
        const badge = $(".board-count", col);
        if (badge) badge.textContent = count;
      });
    }
  }

  /* ---------------------------------------------------------
     14. Status action buttons (Proposals / Invoices — demo-only)
  --------------------------------------------------------- */
  function initStatusActions() {
    $$("[data-set-status]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const targetSel = btn.getAttribute("data-status-target");
        const target = targetSel ? document.querySelector(targetSel) : btn.closest("tr, .card");
        const badge = target ? target.querySelector(".badge") : null;
        const newStatus = btn.getAttribute("data-set-status");
        const map = {
          approved: ["badge-success", "Approved"],
          sent: ["badge-info", "Sent"],
          paid: ["badge-success", "Paid"],
          overdue: ["badge-danger", "Overdue"],
          declined: ["badge-danger", "Declined"],
          draft: ["badge-neutral", "Draft"],
        };
        if (badge && map[newStatus]) {
          badge.className = "badge " + map[newStatus][0];
          badge.textContent = map[newStatus][1];
        }
        showToast("Status updated to " + (map[newStatus] ? map[newStatus][1] : newStatus) + ".", "success");
      });
    });
  }

  /* ---------------------------------------------------------
     15. Set active nav link based on current page
  --------------------------------------------------------- */
  function markActiveNav() {
    const path = window.location.pathname.split("/").pop() || "index.html";
    $$(".main-nav a, .sidebar-nav a, .mobile-nav a").forEach((link) => {
      const href = link.getAttribute("href");
      if (href === path) {
        link.setAttribute("aria-current", "page");
      }
    });
  }

  /* ---------------------------------------------------------
     Init
  --------------------------------------------------------- */
  document.addEventListener("DOMContentLoaded", () => {
    markActiveNav();
    initMobileNav();
    initAppShell();
    initTabs();
    initAccordions();
    initModals();
    initPopoverPositioning();
    initToastTriggers();
    initAlerts();
    initPasswordToggles();
    initFormValidation();
    initTableSort();
    initFilters();
    initCopyButtons();
    initBoard();
    initStatusActions();
  });
})();
